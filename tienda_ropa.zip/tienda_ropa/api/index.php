<?php
/**
 * Punto de entrada de la API RESTful.
 * Incluye el enrutador para procesar las solicitudes.
 * 
 * Requisito: "API RESTful con endpoints CRUD".
 */
require_once __DIR__ . '/routes/api.php';
?>